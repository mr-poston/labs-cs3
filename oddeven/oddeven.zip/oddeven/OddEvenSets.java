import java.util.Arrays;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class OddEvenSets
{
	private Set<Integer> odds;
	private Set<Integer> evens;
	
	public OddEvenSets()
	{
		
	}
	
	public OddEvenSets<String line)
	{
		
	}
	
	@Override
	public String toString()
	{
		return "ODDS : " + odds + "\nEVENS : " + evens + "\n\n";
	}
}
