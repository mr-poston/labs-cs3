public class Grader
{
	public static void main(String[] args)
	{
		OddEvenSets test = new OddEvenSets(args[0]);
		System.out.println(test);
	}
}