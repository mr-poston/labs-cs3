public interface Leaseable {
    public double getMonthlyPayment();
}
