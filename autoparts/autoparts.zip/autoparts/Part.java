/**
 * N.B. Part has to implement Comparable if it is
 * going to be stored in a TreeMap!
 */
public class Part implements Comparable<Part> {
    private String make;
    private String model;
    private String leftOver;
    private int year;

    /**
     * Creates a part object
     */
    public Part(String line) {
        String[] partPieces = line.split(" ");
        int end = partPieces.length;
        // Instantiate make, model, and leftOver
        // year has been instantiated for you!
        make = partPieces[end - 3];
        model = partPieces[end - 2];
        leftOver = "";
        for (int i = 0; i < end - 3; i++) {
            leftOver += " " + partPieces[i];
        }
        year = Integer.parseInt(partPieces[end - 1]);
    }

    // Have to have compareTo if it implements Comparable
    @Override
    public int compareTo(Part other) {
        if (make.equals(other.make)) {
            if (model.equals(other.model)) {
                if (year == other.year) {
                    return leftOver.compareTo(other.leftOver);
                }
                if (year > other.year) {
                    return 1;
                }
                return -1;
            }
            return model.compareTo(other.model);
        }
        return make.compareTo(other.make);
    }

    @Override
    public String toString() {
        return make + " " + model + " " + year + " " + leftOver;
    }
}
