import java.util.Queue;
import java.util.PriorityQueue;

public class PQTester {
	private Queue<String> pQueue;

	/**
	 * Call setPQ with an empty String
	 */
	public PQTester() {
		
	}

	/**
	 * Call setPQ with list
	 */
	public PQTester(String list) {
		
	}

	/**
	 * Initialize pQueue and
	 * add all tokens from list (in order)
	 */
	public void setPQ(String list) {
		
	}
	
	/**
	 * Return the smallest value in pQueue
	 */
	public String getMin() {
		
	}
	
	/**
	 * Return a String of all values in pQueue
	 * in natural order with a space after each element
	 */
	public String getNaturalOrder() {
				
	}

	/**
	 * Write a toString method below!
	 */
	
}