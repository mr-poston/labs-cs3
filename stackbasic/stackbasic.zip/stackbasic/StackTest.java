import java.util.Stack;
import static java.lang.System.*;

public class StackTest {
	private Stack<String> stack;

	// call setStack with an empty String
	public StackTest() {
		
	}

	// call setStack with line
	public StackTest(String line) {
		
	}

	// initialize stack as an empty Stack
	// push each token from line to the stack
	public void setStack(String line) {
		
	}

	// as long as there is something on the stack, pop it and print it!
	public void popEmAll() {
		out.println("popping all items from the stack");
		
	}

	@Override
	public String toString() {
		return "" + stack + "\n";
	}
}
