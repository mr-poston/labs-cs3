import static java.lang.System.*;

public class Skeleton implements Monster {
    // Add instance variables

    // Add a constructor

    // Add code to implement the Monster interface

    // Add a toString method

}
