import java.util.Scanner;

import static java.lang.System.*;

public class MonsterRunner {
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);

        // Ask for name and size
        
        // Instantiate a Monster

        // Ask for name and size

        // Instantiate another Monster

    }
}
