public class ListFunHouse {
    /**
     * This method will return a String representation of the list
     */
    public static String print(ListNode list) {
        String result = "";

        return result;
    }

    /**
     * This method will return the number of nodes present in the list
     */
    public static int nodeCount(ListNode list) {
        int count = 0;

        return count;
    }

    /**
     * This method will create a new node with the smae value as the first
     * node and add this new node to the beginning of the list. Once finished,
     * the first two nodes will have the same value.
     */
    public static void doubleFirst(ListNode list) {

    }

    /**
     * This method will create a new node with the same value as the last
     * node and add this node to the end of the list. Once finished, the last
     * two nodes will have the same value.
     */
    public static void doubleLast(ListNode list) {
        ListNode previous = null;

    }

    /**
     * This method will remove every other node in the list.
     */
    public static void skipEveryOther(ListNode list) {

    }

    /**
     * This mehtod will set the value of every xth node in the list.
     */
    public static void setXthNode(ListNode list, int x, Comparable value) {
        int count = 1;

    }

    /**
     * This method will remove every xth node in the list.
     */
    public static void removeXthNode(ListNode list, int x) {
        int count = 1;

    }
}