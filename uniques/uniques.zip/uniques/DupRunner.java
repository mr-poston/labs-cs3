import java.util.*;

import static java.lang.System.*;

public class DupRunner
{
    public static void main(String[] args)
    {
        // Add tests
    }
}
