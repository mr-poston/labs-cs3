import java.util.ArrayList;
import java.util.Arrays;
import java.util.Set;
import java.util.TreeSet;

public class UniquesDupes {
    public static Set<String> getUniques(String input) {
        Set<String> uniques = new TreeSet<>();

        // Add code

        return uniques;
    }

    public static Set<String> getDupes(String input) {
        // Add code

        return null;
    }
}
