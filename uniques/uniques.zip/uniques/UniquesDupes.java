import java.util.ArrayList;
import java.util.Arrays;
import java.util.Set;
import java.util.TreeSet;

public class UniquesDupes {
    public static Set<String> getUniques(String input) {
        // Create a Set of Strings called `uniques` and instantiate it with a TreeSet
        // Create a List of Strings called `list` and instantiate it with an ArrayList using `input`
        // Add items from `list` to `uniques`

        // Return `uniques`
        return null;
    }

    public static Set<String> getDupes(String input) {
        // Create a Set of Strings called `uniques` and instantiate it with a TreeSet
        // Create a Set of Strings called `dupes` and instantiate it with a TreeSet
        // Create a List of Strings called `list` and instantiate it with an ArrayList using `input`
        // Add items from `list` to `uniques` and determine which items should go in `dupes`

        // Return `dupes`
        return null;
    }
}
