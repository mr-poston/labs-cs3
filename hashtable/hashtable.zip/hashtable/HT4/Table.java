import java.util.LinkedList;

public class Table {
    private LinkedList[] table;

    @SuppressWarnings("unchecked")
    public Table(int size) {
        table = new LinkedList[size];
        // ???
    }

    @SuppressWarnings("unchecked")
    public void add(int value) {
        // add value to table
        // use the table.length in your hash formula
    }

    @SuppressWarnings("unchecked")
    public String toString() {
        String result = "";

        return result;
    }
}