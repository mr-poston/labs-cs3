public class HashTableFive {
    public static void main(String[] args) {
        Table tab = new Table(10);
        tab.add(3);
        tab.add(7);
        tab.add(11);
        tab.add(31);
        tab.add(17);
        tab.add(15);
        System.out.println(tab);
    }
}