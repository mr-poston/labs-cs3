public class Table {
    private ListNode[] table;

    public Table(int size) {
        // size the array
    }

    public void add(int value) {
        // add value to the hashtable
        // use table.length as part of the hash formula
    }

    public String toString() {
        String result = "";

        return result;
    }
}