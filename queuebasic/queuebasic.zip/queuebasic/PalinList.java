import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class PalinList {
    private Queue<String> queue;
    private Stack<String> stack;

    public PalinList() {
        setList("");
    }

    public PalinList(String str) {
        
    }

    public void setList(String str) {
        
    }

    public boolean isPalin() {
        return true;
    }

    @Override
    public String toString() {
        return "";
    }
}