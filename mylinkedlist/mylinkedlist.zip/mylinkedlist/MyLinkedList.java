public class MyLinkedList {
    private ListNode head;

    public MyLinkedList() {

    }

    public MyLinkedList(Comparable value) {

    }

    public void add(Comparable newVal) {

    }

    public boolean contains(Comparable target) {

        return false;
    }

    public Comparable get(int index) {

        return null;
    }

    public int indexOf(Comparable target) {

        return 0;
    }

    public void set(Comparable newVal, int index) {

    }

    public int size() {

        return 0;
    }

    public boolean isEmpty() {
        return false;
    }

    public Comparable remove(int index) {

        return null;
    }

    public void add(Comparable newVal, int index) {

    }

    @Override
    public String toString() {
        String result = "[";

        return result;
    }
}