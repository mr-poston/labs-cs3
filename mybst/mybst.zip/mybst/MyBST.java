public class MyBST {
    // Instance Variable
    private BSTNode root;
    
    // Inner Class
    private class BSTNode {
        //TODO
        
    }
    
    // Constructor
    public MyBST() {
        root = null; // Done!
    }
    
    // Getter
    public BSTNode getRoot() {
        return root; // Done!
    }
    
    public void insert(Integer n) {
        //TODO
        
    }
    
    public boolean contains(Integer n) {
        //TODO
        return false;
    }
    
    public boolean delete(Integer n) {
        //TODO
        return false;
    }
    
    public Integer getMax() {
        //TODO
        return 0;
    }
    
    public Integer getMin() {
        //TODO
        return 0;
    }
    
    public void inOrder() {
        //TODO
        
    }
    
    public void print() {
        //TODO
        
    }
}