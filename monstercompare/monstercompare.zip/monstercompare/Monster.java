import static java.lang.System.*;

public class Monster implements Comparable {
    private int weight;
    private int height;
    private int age;

    // Write a default constructor


    // Write an initialization constructor with parameter ht


    // Write an initialization constructor with parameters ht and wt


    // Write an initialization constructor with parameters ht, wt, and a


    // Accessors - write 'get' methods for all instance variables


    // Modifiers - write 'set' methods for all instance variables


    // Creates a copy of this Object
    public Object clone() {
        // Implement this method
        return new Monster();
    }

    public boolean equals(Object obj) {
        // Implement this method
        return false;
    }

    public int compareTo(Object obj) {
        // Implement this method
        return -1;
    }

    // Write a toString method
}
