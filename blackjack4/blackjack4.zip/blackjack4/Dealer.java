public class Dealer extends Player {

    // Instance Variable
    // Define a deck of Cards

    // Constructor
    public Dealer() {

    }

    /**
     * Shuffle the deck
     */
    public void shuffle() {
        
    }

    /**
     * Return the next card from the deck
     */
    public Card deal() {
        return null;
    }

    /**
     * How many cards are left in the deck?
     */
    public int numCardsLeftInDeck() {
        return 0;
    }

    /**
     * If the dealer's hand value is greater than 17,
     * Add a card to the dealer's hand and return true;
     * Otherwise, return false
     */
    public boolean hit() {
        return false;
    }
}
