import static java.lang.System.*;

public class IteratorReplacerRunner
{
    public static void main(String[] args)
    {
        // Add test cases
    }
}
