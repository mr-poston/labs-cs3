/**
 * Write your own tests in main
 */
public class IteratorRemoverRunner {
    public static void main(String[] args) {
        // add test cases
    }
}
