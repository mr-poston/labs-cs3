import java.util.Map;
import java.util.TreeMap;

public class Histogram {
    private Map<String, Integer> histogram;

    public Histogram() {
        // Call setSentence with an empty String to
        // initialize `histogram`
    
    }

    public Histogram(String sentence) {
        // Call setSentence with given parameter to
        // initialize `histogram`

    }

    public void setSentence(String sentence) {
        // Initialize `histogram` as an empty TreeMap
        // Use split to convert sentence to an array

    }

    @Override
    public String toString() {
        String output = "char\t1---5----01---5\n";

            String stars = "";

        return output + "\n\n";
    }
}
