import static java.lang.System.*;

import java.util.Scanner;

public class BlackJack {
    // Add a Player field
    // Add a Dealer field

    // Constructor
    public BlackJack() {

    }

    public void playGame() {
        // All game logic goes here

    }

    public static void main(String[] args) {
        BlackJack game = new BlackJack();
        game.playGame();
    }
}
