/**
 * This class implements a stack of Integer objects.
 */

import java.util.EmptyStackException;

public class MyStack {

}