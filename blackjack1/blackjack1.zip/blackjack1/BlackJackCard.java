public class BlackJackCard extends Card {

    // Constructors


    @Override
    public int getValue() {
        // Enables you to build the value for the game into the card.
        // This makes writing the whol program a little easier.

        return 0;
    }
}
