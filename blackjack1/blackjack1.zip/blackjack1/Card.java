public class Card {
    public static final String[] FACES = {"ZERO", "ACE", "TWO", "THREE", "FOUR", "FIVE", "SIX",
        "SEVEN", "EIGHT", "NINE", "TEN", "JACK", "QUEEN", "KING"};

    private String suit;
    private int face;

    // Constructors
    

    // Modifiers


    // Accessors
    public int getValue() {
        return face;
    }

    @Override
    public boolean equals(Object obj) {
        // Complete this method
        return false;
    }

    // Complete a toString method
}
