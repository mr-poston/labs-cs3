import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class SpanishToEnglish {
    private Map<String, String> pairs;

    public SpanishToEnglish() {

    }

    public void putEntry(String entry) {

    }

    public String translate(String sent) {
        Scanner scan = new Scanner(sent);
        String output = "";


        return output;
    }

    public String toString() {
        return pairs.toString().replaceAll("\\,", "\n");
    }
}
