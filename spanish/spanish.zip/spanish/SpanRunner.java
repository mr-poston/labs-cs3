import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class SpanRunner {
    public static void main(String[] args) {
        try {

        } catch (IOException e) {
            
        }
    }
}
