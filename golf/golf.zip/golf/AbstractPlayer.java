import java.util.ArrayList;
import java.util.List;

public abstract class AbstractPlayer implements Playerable {
    private ArrayList<Card> cards;
    private int wins;

    // Constructors


    // Modifiers


    // Accessors


    @Override
    public String toString() {
        return "";
    }
}
