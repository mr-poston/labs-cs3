// Define Player class here!!
