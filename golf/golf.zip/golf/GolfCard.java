public class GolfCard extends Card {
    // Constructors


    @Override
    public int getValue() {
        // Aces are 1, Jacks are 0, King is 10, Queen is 10
        // All others are face value

        return 0;
    }
}
