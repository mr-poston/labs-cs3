import static java.lang.System.*;

import java.util.Scanner;

public class Golf {
    // Add Player instance Variables


    // Add Dealer instance Variables


    public Golf() {}

    public void playGame() {
        Scanner keyboard = new Scanner(in);
        char choice = 0;
    }

    public static void main(String[] args) {
        Golf game = new Golf();
        game.playGame();
    }
}
